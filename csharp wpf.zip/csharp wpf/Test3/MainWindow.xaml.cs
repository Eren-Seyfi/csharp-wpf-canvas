﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.ConstrainedExecution;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Test3
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            
                InitializeComponent();
                DrawCar();
                DrawFlower();
            }
        private List<UIElement> childrenList;
        Shape carGlassShape;
        Shape carBodyShape;
        Shape leftWheelShape;
        Shape rightWheelShape;




        private void DrawCar()
            {
                Rectangle carBody = new Rectangle()
                {
                    Width = 200,
                    Height = 50,
                    Fill = Brushes.Black
                };

                Canvas.SetLeft(carBody, 50);
                Canvas.SetTop(carBody, 300);
                canvas.Children.Add(carBody);
            carBodyShape = carBody;


            Rectangle carGlass = new Rectangle()
                {
                    Width = 150,
                    Height = 40,
                    Fill = Brushes.Blue
                };
                Canvas.SetLeft(carGlass, 75);
                Canvas.SetTop(carGlass, 260);
            canvas.Children.Add(carGlass);
            carGlassShape = carGlass;

            Ellipse leftWheel = new Ellipse()
                {
                    Width = 40,
                    Height = 40,
                    Fill = Brushes.Gray
                };
                Canvas.SetLeft(leftWheel, 60);
                Canvas.SetTop(leftWheel, 340);
            canvas.Children.Add(leftWheel);
            leftWheelShape = leftWheel;

            Ellipse rightWheel = new Ellipse()
                {
                    Width = 40,
                    Height = 40,
                    Fill = Brushes.Gray
                };
                Canvas.SetLeft(rightWheel, 190);
                Canvas.SetTop(rightWheel, 340);
            canvas.Children.Add(rightWheel);
            rightWheelShape = rightWheel;

            childrenList = new List<UIElement> { carBody, carGlass, leftWheel, rightWheel };
        }
    

            private void DrawFlower()
            {
                Ellipse flowerBody = new Ellipse()
                {
                    Width = 40,
                    Height = 40,
                    Fill = Brushes.Yellow
                };
                Canvas.SetLeft(flowerBody, 290);
                Canvas.SetTop(flowerBody, 270);
            canvas.Children.Add(flowerBody);

            Ellipse leftPetal = new Ellipse()
                {
                    Width = 20,
                    Height = 20,
                    Fill = Brushes.Red
                };
                Canvas.SetLeft(leftPetal, 280);
                Canvas.SetTop(leftPetal, 280);
            canvas.Children.Add(leftPetal);

            Ellipse rightPetal = new Ellipse()
                {
                    Width = 20,
                    Height = 20,
                    Fill = Brushes.Red
                };
                Canvas.SetLeft(rightPetal, 320);
                Canvas.SetTop(rightPetal, 280);
            canvas.Children.Add(rightPetal);
            Ellipse topPetal = new Ellipse()
                {
                    Width = 20,
                    Height = 20,
                    Fill = Brushes.Red
                };
                Canvas.SetLeft(topPetal, 300);
                Canvas.SetTop(topPetal, 260);
            canvas.Children.Add(topPetal);
            Ellipse bottomPetal = new Ellipse()
                {
                    Width = 20,
                    Height = 20,
                    Fill = Brushes.Red
                };
                Canvas.SetLeft(bottomPetal, 300);
                Canvas.SetTop(bottomPetal, 300);
            canvas.Children.Add(bottomPetal);
            Panel.SetZIndex(flowerBody, canvas.Children.Count - 1);

            // daha çok kırmızı yaprak çizme
            for (int i = 0; i < 8; i++)
            {
                Ellipse petal = new Ellipse()
                {
                    Width = 20,
                    Height = 20,
                    Fill = Brushes.Red
                };

                double angle = i * 45;
                double x = 300 + 30 * Math.Cos(Math.PI * angle / 180);
                double y = 280 - 30 * Math.Sin(Math.PI * angle / 180);

                Canvas.SetLeft(petal, x);
                Canvas.SetTop(petal, y);
                canvas.Children.Add(petal);
                childrenList.Add(petal);
            }

            childrenList.AddRange(new UIElement[] { flowerBody, leftPetal, rightPetal, topPetal, bottomPetal });
    }

        private void Window_KeyDown(object sender, KeyEventArgs e)
        {
            // İleri
            if (e.Key == Key.W)
            {
                foreach (UIElement child in childrenList)
                {
                    double top = Canvas.GetTop(child);
                    double top1 = Canvas.GetTop(carGlassShape);

                    if (top1 > 0 ) 
                        Canvas.SetTop(child, top - 10);
                }
            }
            // Sol
            else if (e.Key == Key.A)
            {
                foreach (UIElement child in childrenList)
                {
                    double left = Canvas.GetLeft(child);
                    double left1 = Canvas.GetTop(carBodyShape);
                    if (left1 > 0)
                        Canvas.SetLeft(child, left - 10);
                }
            }
            // Aşağı
            else if (e.Key == Key.S)
            {
                foreach (UIElement child in childrenList)
                {
                    double top = Canvas.GetTop(child);
                    double top2 = Canvas.GetTop(leftWheelShape);
                    if (top + child.RenderSize.Height < canvas.ActualHeight)
                        Canvas.SetTop(child, top + 10);
                }
            }
            // Sağ
            else if (e.Key == Key.D)
            {
                foreach (UIElement child in childrenList)
                {
                    double left = Canvas.GetLeft(child);
                    double left2 = Canvas.GetLeft(rightWheelShape);
                    if (left + child.RenderSize.Width < canvas.ActualWidth)
                        Canvas.SetLeft(child, left + 10);
                }
            }
        }

    }

}
